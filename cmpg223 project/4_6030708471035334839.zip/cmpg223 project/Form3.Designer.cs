﻿namespace cmpg223_project
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbIdRemove = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnRemove = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbFnameUpdate = new System.Windows.Forms.TextBox();
            this.tbLnameUpdate = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tbPhoneUpdate = new System.Windows.Forms.TextBox();
            this.tbEmailUpdate = new System.Windows.Forms.TextBox();
            this.tbCompUpdate = new System.Windows.Forms.TextBox();
            this.tbIdUpdate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbFname = new System.Windows.Forms.TextBox();
            this.tbLname = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbPhone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbCompName = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbProjectIdRemove = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnProjectRemove = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbAssignemntUpdate = new System.Windows.Forms.TextBox();
            this.tbProjectDescUpdate = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tbScheduleUpdate = new System.Windows.Forms.TextBox();
            this.tbPhaseIdUpdate = new System.Windows.Forms.TextBox();
            this.tbClientUpdate = new System.Windows.Forms.TextBox();
            this.tbProjectIdUpdate = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnProjectUpdate = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tbProjectDesc = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.tbScheduleIdAdd = new System.Windows.Forms.TextBox();
            this.tbAssignmentAddId = new System.Windows.Forms.TextBox();
            this.tbClientIdAdd = new System.Windows.Forms.TextBox();
            this.tbPhaseIdAdd = new System.Windows.Forms.TextBox();
            this.btnProjectAdd = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tbAssignmentDel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btnRemoveProjectAssignment = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tbProjId = new System.Windows.Forms.TextBox();
            this.tbRoleID = new System.Windows.Forms.TextBox();
            this.tbEmpId = new System.Windows.Forms.TextBox();
            this.btnAddProjectAssignment = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(932, 477);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(924, 448);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Mange Clients";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::cmpg223_project.Properties.Resources.DevTracker_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(255, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbIdRemove);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.btnRemove);
            this.groupBox3.Location = new System.Drawing.Point(557, 101);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(267, 331);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Remove Client";
            // 
            // tbIdRemove
            // 
            this.tbIdRemove.Location = new System.Drawing.Point(125, 39);
            this.tbIdRemove.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbIdRemove.Name = "tbIdRemove";
            this.tbIdRemove.Size = new System.Drawing.Size(132, 22);
            this.tbIdRemove.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 43);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Client ID";
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(8, 295);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(251, 28);
            this.btnRemove.TabIndex = 0;
            this.btnRemove.Text = "Remove Client";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbFnameUpdate);
            this.groupBox2.Controls.Add(this.tbLnameUpdate);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.tbPhoneUpdate);
            this.groupBox2.Controls.Add(this.tbEmailUpdate);
            this.groupBox2.Controls.Add(this.tbCompUpdate);
            this.groupBox2.Controls.Add(this.tbIdUpdate);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btnUpdate);
            this.groupBox2.Location = new System.Drawing.Point(283, 101);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(267, 331);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Update Client";
            // 
            // tbFnameUpdate
            // 
            this.tbFnameUpdate.Location = new System.Drawing.Point(125, 186);
            this.tbFnameUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFnameUpdate.Name = "tbFnameUpdate";
            this.tbFnameUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbFnameUpdate.TabIndex = 19;
            // 
            // tbLnameUpdate
            // 
            this.tbLnameUpdate.Location = new System.Drawing.Point(125, 215);
            this.tbLnameUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbLnameUpdate.Name = "tbLnameUpdate";
            this.tbLnameUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbLnameUpdate.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 190);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 16);
            this.label11.TabIndex = 17;
            this.label11.Text = "First Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 224);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 16);
            this.label12.TabIndex = 16;
            this.label12.Text = "Last Name";
            // 
            // tbPhoneUpdate
            // 
            this.tbPhoneUpdate.Location = new System.Drawing.Point(125, 146);
            this.tbPhoneUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPhoneUpdate.Name = "tbPhoneUpdate";
            this.tbPhoneUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbPhoneUpdate.TabIndex = 12;
            // 
            // tbEmailUpdate
            // 
            this.tbEmailUpdate.Location = new System.Drawing.Point(125, 113);
            this.tbEmailUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbEmailUpdate.Name = "tbEmailUpdate";
            this.tbEmailUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbEmailUpdate.TabIndex = 13;
            // 
            // tbCompUpdate
            // 
            this.tbCompUpdate.Location = new System.Drawing.Point(125, 76);
            this.tbCompUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbCompUpdate.Name = "tbCompUpdate";
            this.tbCompUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbCompUpdate.TabIndex = 14;
            // 
            // tbIdUpdate
            // 
            this.tbIdUpdate.Location = new System.Drawing.Point(125, 39);
            this.tbIdUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbIdUpdate.Name = "tbIdUpdate";
            this.tbIdUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbIdUpdate.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 43);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 16);
            this.label8.TabIndex = 11;
            this.label8.Text = "Client ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 150);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "PhoneNumber";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 117);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 80);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Company Name";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(8, 295);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(251, 28);
            this.btnUpdate.TabIndex = 0;
            this.btnUpdate.Text = "Update Client";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbFname);
            this.groupBox1.Controls.Add(this.tbLname);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.tbEmail);
            this.groupBox1.Controls.Add(this.tbPhone);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbCompName);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 101);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(267, 331);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add a client";
            // 
            // tbFname
            // 
            this.tbFname.Location = new System.Drawing.Point(125, 151);
            this.tbFname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbFname.Name = "tbFname";
            this.tbFname.Size = new System.Drawing.Size(132, 22);
            this.tbFname.TabIndex = 10;
            // 
            // tbLname
            // 
            this.tbLname.Location = new System.Drawing.Point(125, 181);
            this.tbLname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbLname.Name = "tbLname";
            this.tbLname.Size = new System.Drawing.Size(132, 22);
            this.tbLname.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 155);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "First Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 190);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 16);
            this.label9.TabIndex = 7;
            this.label9.Text = "Last Name";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(125, 71);
            this.tbEmail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(132, 22);
            this.tbEmail.TabIndex = 6;
            // 
            // tbPhone
            // 
            this.tbPhone.Location = new System.Drawing.Point(125, 113);
            this.tbPhone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPhone.Name = "tbPhone";
            this.tbPhone.Size = new System.Drawing.Size(132, 22);
            this.tbPhone.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 117);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "PhoneNumber";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Email";
            // 
            // tbCompName
            // 
            this.tbCompName.Location = new System.Drawing.Point(125, 34);
            this.tbCompName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbCompName.Name = "tbCompName";
            this.tbCompName.Size = new System.Drawing.Size(132, 22);
            this.tbCompName.TabIndex = 2;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(8, 295);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(251, 28);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add Client";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 43);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Company Name";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(1043, 510);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Mange Projects";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tbProjectIdRemove);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.btnProjectRemove);
            this.groupBox4.Location = new System.Drawing.Point(713, 79);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(267, 331);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Remove Project";
            // 
            // tbProjectIdRemove
            // 
            this.tbProjectIdRemove.Location = new System.Drawing.Point(125, 39);
            this.tbProjectIdRemove.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbProjectIdRemove.Name = "tbProjectIdRemove";
            this.tbProjectIdRemove.Size = new System.Drawing.Size(132, 22);
            this.tbProjectIdRemove.TabIndex = 11;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 43);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "Project ID";
            // 
            // btnProjectRemove
            // 
            this.btnProjectRemove.Location = new System.Drawing.Point(8, 295);
            this.btnProjectRemove.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnProjectRemove.Name = "btnProjectRemove";
            this.btnProjectRemove.Size = new System.Drawing.Size(251, 28);
            this.btnProjectRemove.TabIndex = 0;
            this.btnProjectRemove.Text = "Remove Project";
            this.btnProjectRemove.UseVisualStyleBackColor = true;
            this.btnProjectRemove.Click += new System.EventHandler(this.btnProjectRemove_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tbAssignemntUpdate);
            this.groupBox5.Controls.Add(this.tbProjectDescUpdate);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.tbScheduleUpdate);
            this.groupBox5.Controls.Add(this.tbPhaseIdUpdate);
            this.groupBox5.Controls.Add(this.tbClientUpdate);
            this.groupBox5.Controls.Add(this.tbProjectIdUpdate);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.btnProjectUpdate);
            this.groupBox5.Location = new System.Drawing.Point(361, 79);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Size = new System.Drawing.Size(352, 331);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Update Project";
            // 
            // tbAssignemntUpdate
            // 
            this.tbAssignemntUpdate.Location = new System.Drawing.Point(171, 186);
            this.tbAssignemntUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbAssignemntUpdate.Name = "tbAssignemntUpdate";
            this.tbAssignemntUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbAssignemntUpdate.TabIndex = 19;
            // 
            // tbProjectDescUpdate
            // 
            this.tbProjectDescUpdate.Location = new System.Drawing.Point(171, 215);
            this.tbProjectDescUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbProjectDescUpdate.Name = "tbProjectDescUpdate";
            this.tbProjectDescUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbProjectDescUpdate.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 190);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 16);
            this.label14.TabIndex = 17;
            this.label14.Text = "Assignment ID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 224);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 16);
            this.label15.TabIndex = 16;
            this.label15.Text = "Project Description ";
            // 
            // tbScheduleUpdate
            // 
            this.tbScheduleUpdate.Location = new System.Drawing.Point(171, 146);
            this.tbScheduleUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbScheduleUpdate.Name = "tbScheduleUpdate";
            this.tbScheduleUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbScheduleUpdate.TabIndex = 12;
            // 
            // tbPhaseIdUpdate
            // 
            this.tbPhaseIdUpdate.Location = new System.Drawing.Point(171, 113);
            this.tbPhaseIdUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPhaseIdUpdate.Name = "tbPhaseIdUpdate";
            this.tbPhaseIdUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbPhaseIdUpdate.TabIndex = 13;
            // 
            // tbClientUpdate
            // 
            this.tbClientUpdate.Location = new System.Drawing.Point(171, 76);
            this.tbClientUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbClientUpdate.Name = "tbClientUpdate";
            this.tbClientUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbClientUpdate.TabIndex = 14;
            // 
            // tbProjectIdUpdate
            // 
            this.tbProjectIdUpdate.Location = new System.Drawing.Point(171, 39);
            this.tbProjectIdUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbProjectIdUpdate.Name = "tbProjectIdUpdate";
            this.tbProjectIdUpdate.Size = new System.Drawing.Size(132, 22);
            this.tbProjectIdUpdate.TabIndex = 15;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 43);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 16);
            this.label16.TabIndex = 11;
            this.label16.Text = "Project ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 150);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 16);
            this.label17.TabIndex = 9;
            this.label17.Text = "Schedule ID";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 117);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 16);
            this.label18.TabIndex = 8;
            this.label18.Text = "Phase ID";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 80);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 16);
            this.label19.TabIndex = 7;
            this.label19.Text = "Client ID";
            // 
            // btnProjectUpdate
            // 
            this.btnProjectUpdate.Location = new System.Drawing.Point(8, 295);
            this.btnProjectUpdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnProjectUpdate.Name = "btnProjectUpdate";
            this.btnProjectUpdate.Size = new System.Drawing.Size(251, 28);
            this.btnProjectUpdate.TabIndex = 0;
            this.btnProjectUpdate.Text = "Update Project";
            this.btnProjectUpdate.UseVisualStyleBackColor = true;
            this.btnProjectUpdate.Click += new System.EventHandler(this.btnProjectUpdate_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tbProjectDesc);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Controls.Add(this.label28);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.tbScheduleIdAdd);
            this.groupBox6.Controls.Add(this.tbAssignmentAddId);
            this.groupBox6.Controls.Add(this.tbClientIdAdd);
            this.groupBox6.Controls.Add(this.tbPhaseIdAdd);
            this.groupBox6.Controls.Add(this.btnProjectAdd);
            this.groupBox6.Location = new System.Drawing.Point(33, 79);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox6.Size = new System.Drawing.Size(333, 331);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Add Project";
            // 
            // tbProjectDesc
            // 
            this.tbProjectDesc.Location = new System.Drawing.Point(187, 188);
            this.tbProjectDesc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbProjectDesc.Name = "tbProjectDesc";
            this.tbProjectDesc.Size = new System.Drawing.Size(132, 22);
            this.tbProjectDesc.TabIndex = 24;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(4, 158);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 16);
            this.label25.TabIndex = 23;
            this.label25.Text = "Assignment ID";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(4, 192);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(123, 16);
            this.label26.TabIndex = 22;
            this.label26.Text = "Project Description ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(4, 118);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(80, 16);
            this.label28.TabIndex = 20;
            this.label28.Text = "Schedule ID";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(4, 85);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(62, 16);
            this.label29.TabIndex = 19;
            this.label29.Text = "Phase ID";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(4, 48);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(56, 16);
            this.label30.TabIndex = 18;
            this.label30.Text = "Client ID";
            // 
            // tbScheduleIdAdd
            // 
            this.tbScheduleIdAdd.Location = new System.Drawing.Point(187, 119);
            this.tbScheduleIdAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbScheduleIdAdd.Name = "tbScheduleIdAdd";
            this.tbScheduleIdAdd.Size = new System.Drawing.Size(132, 22);
            this.tbScheduleIdAdd.TabIndex = 10;
            // 
            // tbAssignmentAddId
            // 
            this.tbAssignmentAddId.Location = new System.Drawing.Point(187, 149);
            this.tbAssignmentAddId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbAssignmentAddId.Name = "tbAssignmentAddId";
            this.tbAssignmentAddId.Size = new System.Drawing.Size(132, 22);
            this.tbAssignmentAddId.TabIndex = 9;
            // 
            // tbClientIdAdd
            // 
            this.tbClientIdAdd.Location = new System.Drawing.Point(187, 39);
            this.tbClientIdAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbClientIdAdd.Name = "tbClientIdAdd";
            this.tbClientIdAdd.Size = new System.Drawing.Size(132, 22);
            this.tbClientIdAdd.TabIndex = 6;
            // 
            // tbPhaseIdAdd
            // 
            this.tbPhaseIdAdd.Location = new System.Drawing.Point(187, 81);
            this.tbPhaseIdAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbPhaseIdAdd.Name = "tbPhaseIdAdd";
            this.tbPhaseIdAdd.Size = new System.Drawing.Size(132, 22);
            this.tbPhaseIdAdd.TabIndex = 5;
            // 
            // btnProjectAdd
            // 
            this.btnProjectAdd.Location = new System.Drawing.Point(8, 295);
            this.btnProjectAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnProjectAdd.Name = "btnProjectAdd";
            this.btnProjectAdd.Size = new System.Drawing.Size(251, 28);
            this.btnProjectAdd.TabIndex = 0;
            this.btnProjectAdd.Text = "Add Project";
            this.btnProjectAdd.UseVisualStyleBackColor = true;
            this.btnProjectAdd.Click += new System.EventHandler(this.btnProjectAdd_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage3.Size = new System.Drawing.Size(1043, 510);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Manage Project Assignments";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tbAssignmentDel);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.btnRemoveProjectAssignment);
            this.groupBox7.Location = new System.Drawing.Point(449, 89);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox7.Size = new System.Drawing.Size(267, 331);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Remove Project Assignment";
            // 
            // tbAssignmentDel
            // 
            this.tbAssignmentDel.Location = new System.Drawing.Point(125, 39);
            this.tbAssignmentDel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbAssignmentDel.Name = "tbAssignmentDel";
            this.tbAssignmentDel.Size = new System.Drawing.Size(132, 22);
            this.tbAssignmentDel.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(8, 43);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(93, 16);
            this.label20.TabIndex = 10;
            this.label20.Text = "Assignment ID";
            // 
            // btnRemoveProjectAssignment
            // 
            this.btnRemoveProjectAssignment.Location = new System.Drawing.Point(8, 295);
            this.btnRemoveProjectAssignment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnRemoveProjectAssignment.Name = "btnRemoveProjectAssignment";
            this.btnRemoveProjectAssignment.Size = new System.Drawing.Size(251, 28);
            this.btnRemoveProjectAssignment.TabIndex = 0;
            this.btnRemoveProjectAssignment.Text = "Remove";
            this.btnRemoveProjectAssignment.UseVisualStyleBackColor = true;
            this.btnRemoveProjectAssignment.Click += new System.EventHandler(this.btnRemoveProjectAssignment_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.label27);
            this.groupBox8.Controls.Add(this.tbProjId);
            this.groupBox8.Controls.Add(this.tbRoleID);
            this.groupBox8.Controls.Add(this.tbEmpId);
            this.groupBox8.Controls.Add(this.btnAddProjectAssignment);
            this.groupBox8.Location = new System.Drawing.Point(47, 89);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox8.Size = new System.Drawing.Size(333, 331);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Add Project Assignment";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(4, 123);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 16);
            this.label23.TabIndex = 20;
            this.label23.Text = "Project ID";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(4, 85);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(85, 16);
            this.label24.TabIndex = 19;
            this.label24.Text = "Employee ID";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(4, 48);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 16);
            this.label27.TabIndex = 18;
            this.label27.Text = "Role ID";
            // 
            // tbProjId
            // 
            this.tbProjId.Location = new System.Drawing.Point(187, 119);
            this.tbProjId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbProjId.Name = "tbProjId";
            this.tbProjId.Size = new System.Drawing.Size(132, 22);
            this.tbProjId.TabIndex = 10;
            // 
            // tbRoleID
            // 
            this.tbRoleID.Location = new System.Drawing.Point(187, 39);
            this.tbRoleID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbRoleID.Name = "tbRoleID";
            this.tbRoleID.Size = new System.Drawing.Size(132, 22);
            this.tbRoleID.TabIndex = 6;
            // 
            // tbEmpId
            // 
            this.tbEmpId.Location = new System.Drawing.Point(187, 81);
            this.tbEmpId.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbEmpId.Name = "tbEmpId";
            this.tbEmpId.Size = new System.Drawing.Size(132, 22);
            this.tbEmpId.TabIndex = 5;
            // 
            // btnAddProjectAssignment
            // 
            this.btnAddProjectAssignment.Location = new System.Drawing.Point(8, 295);
            this.btnAddProjectAssignment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddProjectAssignment.Name = "btnAddProjectAssignment";
            this.btnAddProjectAssignment.Size = new System.Drawing.Size(251, 28);
            this.btnAddProjectAssignment.TabIndex = 0;
            this.btnAddProjectAssignment.Text = "Add";
            this.btnAddProjectAssignment.UseVisualStyleBackColor = true;
            this.btnAddProjectAssignment.Click += new System.EventHandler(this.btnAddProjectAssignment_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(81, 500);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "Go Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form3";
            this.Text = "Admin Form";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbCompName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbPhone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbIdRemove;
        private System.Windows.Forms.TextBox tbPhoneUpdate;
        private System.Windows.Forms.TextBox tbEmailUpdate;
        private System.Windows.Forms.TextBox tbCompUpdate;
        private System.Windows.Forms.TextBox tbIdUpdate;
        private System.Windows.Forms.TextBox tbFname;
        private System.Windows.Forms.TextBox tbLname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbFnameUpdate;
        private System.Windows.Forms.TextBox tbLnameUpdate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tbProjectIdRemove;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnProjectRemove;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox tbAssignemntUpdate;
        private System.Windows.Forms.TextBox tbProjectDescUpdate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbScheduleUpdate;
        private System.Windows.Forms.TextBox tbPhaseIdUpdate;
        private System.Windows.Forms.TextBox tbClientUpdate;
        private System.Windows.Forms.TextBox tbProjectIdUpdate;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnProjectUpdate;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox tbScheduleIdAdd;
        private System.Windows.Forms.TextBox tbAssignmentAddId;
        private System.Windows.Forms.TextBox tbClientIdAdd;
        private System.Windows.Forms.TextBox tbPhaseIdAdd;
        private System.Windows.Forms.Button btnProjectAdd;
        private System.Windows.Forms.TextBox tbProjectDesc;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox tbAssignmentDel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnRemoveProjectAssignment;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbProjId;
        private System.Windows.Forms.TextBox tbRoleID;
        private System.Windows.Forms.TextBox tbEmpId;
        private System.Windows.Forms.Button btnAddProjectAssignment;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
    }
}
﻿namespace cmpg223_project
{
    partial class registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.eEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.empSignUP = new System.Windows.Forms.Button();
            this.eNr = new System.Windows.Forms.TextBox();
            this.eLName = new System.Windows.Forms.TextBox();
            this.eFName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cFName = new System.Windows.Forms.TextBox();
            this.cLName = new System.Windows.Forms.TextBox();
            this.clientsSignUP = new System.Windows.Forms.Button();
            this.cNr = new System.Windows.Forms.TextBox();
            this.cEmail = new System.Windows.Forms.TextBox();
            this.cCompanyname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.generateID = new System.Windows.Forms.Button();
            this.IDtxt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.eEmail);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.empSignUP);
            this.groupBox1.Controls.Add(this.eNr);
            this.groupBox1.Controls.Add(this.eLName);
            this.groupBox1.Controls.Add(this.eFName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(38, 234);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 360);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employees ";
            // 
            // eEmail
            // 
            this.eEmail.Location = new System.Drawing.Point(207, 225);
            this.eEmail.Name = "eEmail";
            this.eEmail.Size = new System.Drawing.Size(100, 22);
            this.eEmail.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(144, 231);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Email: ";
            // 
            // empSignUP
            // 
            this.empSignUP.Location = new System.Drawing.Point(110, 283);
            this.empSignUP.Name = "empSignUP";
            this.empSignUP.Size = new System.Drawing.Size(107, 46);
            this.empSignUP.TabIndex = 6;
            this.empSignUP.Text = "Sign Up";
            this.empSignUP.UseVisualStyleBackColor = true;
            this.empSignUP.Click += new System.EventHandler(this.button1_Click);
            // 
            // eNr
            // 
            this.eNr.Location = new System.Drawing.Point(207, 174);
            this.eNr.Name = "eNr";
            this.eNr.Size = new System.Drawing.Size(100, 22);
            this.eNr.TabIndex = 5;
            // 
            // eLName
            // 
            this.eLName.Location = new System.Drawing.Point(207, 115);
            this.eLName.Name = "eLName";
            this.eLName.Size = new System.Drawing.Size(100, 22);
            this.eLName.TabIndex = 4;
            // 
            // eFName
            // 
            this.eFName.Location = new System.Drawing.Point(207, 59);
            this.eFName.Name = "eFName";
            this.eFName.Size = new System.Drawing.Size(100, 22);
            this.eFName.TabIndex = 3;
            this.eFName.TextChanged += new System.EventHandler(this.eName_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Contact Number: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(116, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(116, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cFName);
            this.groupBox2.Controls.Add(this.cLName);
            this.groupBox2.Controls.Add(this.clientsSignUP);
            this.groupBox2.Controls.Add(this.cNr);
            this.groupBox2.Controls.Add(this.cEmail);
            this.groupBox2.Controls.Add(this.cCompanyname);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(468, 234);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(424, 360);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Clients";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(143, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 16);
            this.label10.TabIndex = 10;
            this.label10.Text = "Last Name: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(143, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "First Name: ";
            // 
            // cFName
            // 
            this.cFName.Location = new System.Drawing.Point(229, 40);
            this.cFName.Name = "cFName";
            this.cFName.Size = new System.Drawing.Size(166, 22);
            this.cFName.TabIndex = 8;
            // 
            // cLName
            // 
            this.cLName.Location = new System.Drawing.Point(229, 80);
            this.cLName.Name = "cLName";
            this.cLName.Size = new System.Drawing.Size(166, 22);
            this.cLName.TabIndex = 7;
            // 
            // clientsSignUP
            // 
            this.clientsSignUP.Location = new System.Drawing.Point(162, 272);
            this.clientsSignUP.Name = "clientsSignUP";
            this.clientsSignUP.Size = new System.Drawing.Size(96, 40);
            this.clientsSignUP.TabIndex = 6;
            this.clientsSignUP.Text = "Sign Up";
            this.clientsSignUP.UseVisualStyleBackColor = true;
            this.clientsSignUP.Click += new System.EventHandler(this.clientsSignUP_Click);
            // 
            // cNr
            // 
            this.cNr.Location = new System.Drawing.Point(229, 204);
            this.cNr.Name = "cNr";
            this.cNr.Size = new System.Drawing.Size(166, 22);
            this.cNr.TabIndex = 5;
            // 
            // cEmail
            // 
            this.cEmail.Location = new System.Drawing.Point(229, 168);
            this.cEmail.Name = "cEmail";
            this.cEmail.Size = new System.Drawing.Size(166, 22);
            this.cEmail.TabIndex = 4;
            // 
            // cCompanyname
            // 
            this.cCompanyname.Location = new System.Drawing.Point(229, 129);
            this.cCompanyname.Name = "cCompanyname";
            this.cCompanyname.Size = new System.Drawing.Size(166, 22);
            this.cCompanyname.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(114, 207);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Contact Number: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(114, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Company email: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(54, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Enter your company name: ";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(308, 78);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(91, 20);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Employee";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(523, 78);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(62, 20);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Client";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(316, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(283, 32);
            this.label7.TabIndex = 4;
            this.label7.Text = "             Are you a client or emplyee ?\r\n(Check the correct box to view the si" +
    "gn up form)";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::cmpg223_project.Properties.Resources.DevTracker_logo;
            this.pictureBox1.Location = new System.Drawing.Point(38, 13);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 93);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // generateID
            // 
            this.generateID.Location = new System.Drawing.Point(319, 156);
            this.generateID.Name = "generateID";
            this.generateID.Size = new System.Drawing.Size(91, 38);
            this.generateID.TabIndex = 8;
            this.generateID.Text = "User ID";
            this.generateID.UseVisualStyleBackColor = true;
            this.generateID.Click += new System.EventHandler(this.generateID_Click);
            // 
            // IDtxt
            // 
            this.IDtxt.Location = new System.Drawing.Point(455, 164);
            this.IDtxt.Name = "IDtxt";
            this.IDtxt.Size = new System.Drawing.Size(100, 22);
            this.IDtxt.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(301, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(302, 16);
            this.label11.TabIndex = 10;
            this.label11.Text = "(Click the button bellow to get your unique User ID)";
            // 
            // registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 626);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.IDtxt);
            this.Controls.Add(this.generateID);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "registration";
            this.Text = "registration";
            this.Load += new System.EventHandler(this.registration_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button empSignUP;
        private System.Windows.Forms.TextBox eNr;
        private System.Windows.Forms.TextBox eLName;
        private System.Windows.Forms.TextBox eFName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button clientsSignUP;
        private System.Windows.Forms.TextBox cNr;
        private System.Windows.Forms.TextBox cEmail;
        private System.Windows.Forms.TextBox cCompanyname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox eEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox cFName;
        private System.Windows.Forms.TextBox cLName;
        private System.Windows.Forms.Button generateID;
        private System.Windows.Forms.TextBox IDtxt;
        private System.Windows.Forms.Label label11;
    }
}